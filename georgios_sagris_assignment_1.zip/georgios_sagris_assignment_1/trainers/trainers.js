document.querySelector(`.button`).addEventListener(`click`, function(){

    if (document.getElementById(`subject-add`).value === `initial`) {
        alert(`You have not selected a value for the "Subject:" attribute!`)
    }

});