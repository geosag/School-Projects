document.querySelector(`.checkbox-add`).style.display = `none`;
document.querySelector(`.checkbox-add-1`).style.display = `none`;
document.querySelector(`.checkbox-add-2`).style.display = `none`;

let select = document.querySelector("#course-add");

let label = document.createElement(`label`);
document.querySelector('.checkbox-add').appendChild(label);

let label1 = document.createElement(`label`);
document.querySelector('.checkbox-add-1').appendChild(label1);

let label2 = document.createElement(`label`);
document.querySelector('.checkbox-add-2').appendChild(label2);


let input = document.createElement(`input`);
let input1 = document.createElement(`input`);
let input2 = document.createElement(`input`);

select.addEventListener(`change`, function() {

    let selectedText = select.options[select.selectedIndex].text;

    if (selectedText === `Javascript`) {

        document.querySelector(`.checkbox-add`).style.display = `flex`;
        document.querySelector(`.checkbox-add-1`).style.display = `flex`;
        document.querySelector(`.checkbox-add-2`).style.display = `flex`;
            
        label.innerHTML = `Assignment 7`;
        label1.innerHTML = `Assignment  8`;
        label2.innerHTML = `Assignment  9`;

        label.style.fontSize = `20px`;
        label.style.fontWeight = `bold`;
        label.style.width = `30%`;

        label1.style.fontSize = `20px`;
        label1.style.fontWeight = `bold`;
        label1.style.width = `30%`;
        
        label2.style.fontSize = `20px`;
        label2.style.fontWeight = `bold`;
        label2.style.width = `30%`;

        document.querySelector(`.checkbox-add`).appendChild(input);
        input.setAttribute(`type`, `checkbox`);
        
        document.querySelector(`.checkbox-add-1`).appendChild(input1);
        input1.setAttribute(`type`, `checkbox`);

        document.querySelector(`.checkbox-add-2`).appendChild(input2);
        input2.setAttribute(`type`, `checkbox`);
        
    } else if (selectedText === `Java`) {
        document.querySelector(`.checkbox-add`).style.display = `flex`;
        document.querySelector(`.checkbox-add-1`).style.display = `flex`;
        document.querySelector(`.checkbox-add-2`).style.display = `flex`;

        label.innerHTML = `Assignment  1`;
        label1.innerHTML = `Assignment  2`;
        label2.innerHTML = `Assignment  3`;

        label.style.fontSize = `20px`;
        label.style.fontWeight = `bold`;
        label.style.width = `30%`;

        label1.style.fontSize = `20px`;
        label1.style.fontWeight = `bold`;
        label1.style.width = `30%`;
        
        label2.style.fontSize = `20px`;
        label2.style.fontWeight = `bold`;
        label2.style.width = `30%`;

        document.querySelector(`.checkbox-add`).appendChild(input);
        input.setAttribute(`type`, `checkbox`);
        
        document.querySelector(`.checkbox-add-1`).appendChild(input1);
        input1.setAttribute(`type`, `checkbox`);

        document.querySelector(`.checkbox-add-2`).appendChild(input2);
        input2.setAttribute(`type`, `checkbox`);

    } else if (selectedText === `HTML & CSS`) {
        document.querySelector(`.checkbox-add`).style.display = `flex`;
        document.querySelector(`.checkbox-add-1`).style.display = `flex`;
        document.querySelector(`.checkbox-add-2`).style.display = `flex`;

        label.innerHTML = `Assignment  4`;
        label1.innerHTML = `Assignment  5`;
        label2.innerHTML = `Assignment  6`;

        label.style.fontSize = `20px`;
        label.style.fontWeight = `bold`;
        label.style.width = `30%`;

        label1.style.fontSize = `20px`;
        label1.style.fontWeight = `bold`;
        label1.style.width = `30%`;
        
        label2.style.fontSize = `20px`;
        label2.style.fontWeight = `bold`;
        label2.style.width = `30%`;

        document.querySelector(`.checkbox-add`).appendChild(input);
        input.setAttribute(`type`, `checkbox`);
        
        document.querySelector(`.checkbox-add-1`).appendChild(input1);
        input1.setAttribute(`type`, `checkbox`);

        document.querySelector(`.checkbox-add-2`).appendChild(input2);
        input2.setAttribute(`type`, `checkbox`);

    } else {
        document.querySelector(`.checkbox-add`).style.display = `none`;
        document.querySelector(`.checkbox-add-1`).style.display = `none`;
        document.querySelector(`.checkbox-add-2`).style.display = `none`;

    }
        
        });

// End of container-1

let select1 = document.querySelector("#course-edit");

let labelEdit = document.createElement(`label`);
document.querySelector('.checkbox-edit').appendChild(labelEdit);

let labelEdit1 = document.createElement(`label`);
document.querySelector('.checkbox-edit-1').appendChild(labelEdit1);

let labelEdit2 = document.createElement(`label`);
document.querySelector('.checkbox-edit-2').appendChild(labelEdit2);

labelEdit.innerHTML = `Assignment 4`;
labelEdit1.innerHTML = `Assignment 5`;
labelEdit2.innerHTML = `Assignment 6`;

let inputEdit = document.createElement(`input`);
let inputEdit1 = document.createElement(`input`);
let inputEdit2 = document.createElement(`input`);

labelEdit.style.fontSize = `20px`;
labelEdit.style.fontWeight = `bold`;
labelEdit.style.width = `30%`;

labelEdit1.style.fontSize = `20px`;
labelEdit1.style.fontWeight = `bold`;
labelEdit1.style.width = `30%`;
        
labelEdit2.style.fontSize = `20px`;
labelEdit2.style.fontWeight = `bold`;
labelEdit2.style.width = `30%`;

document.querySelector(`.checkbox-edit`).appendChild(inputEdit);
inputEdit.setAttribute(`type`, `checkbox`);
inputEdit.checked = true;

document.querySelector(`.checkbox-edit-1`).appendChild(inputEdit1);
inputEdit1.setAttribute(`type`, `checkbox`);
inputEdit1.checked = true;

document.querySelector(`.checkbox-edit-2`).appendChild(inputEdit2);
inputEdit2.setAttribute(`type`, `checkbox`);
inputEdit2.checked = true;

        

select1.addEventListener(`change`, function() {

    inputEdit.checked = false;
    inputEdit1.checked = false;
    inputEdit2.checked = false;

    let selectedText = select1.options[select1.selectedIndex].text;

    if (selectedText === `Javascript`) {

        document.querySelector(`.checkbox-edit`).style.display = `flex`;
        document.querySelector(`.checkbox-edit-1`).style.display = `flex`;
        document.querySelector(`.checkbox-edit-2`).style.display = `flex`;
            
        labelEdit.innerHTML = `Assignment  7`;
        labelEdit1.innerHTML = `Assignment  8`;
        labelEdit2.innerHTML = `Assignment  9`;

        labelEdit.style.fontSize = `20px`;
        labelEdit.style.fontWeight = `bold`;
        labelEdit.style.width = `30%`;

        labelEdit1.style.fontSize = `20px`;
        labelEdit1.style.fontWeight = `bold`;
        labelEdit1.style.width = `30%`;
        
        labelEdit2.style.fontSize = `20px`;
        labelEdit2.style.fontWeight = `bold`;
        labelEdit2.style.width = `30%`;

        document.querySelector(`.checkbox-edit`).appendChild(inputEdit);
        inputEdit.setAttribute(`type`, `checkbox`);
        
        
        document.querySelector(`.checkbox-edit-1`).appendChild(inputEdit1);
        inputEdit1.setAttribute(`type`, `checkbox`);
        

        document.querySelector(`.checkbox-edit-2`).appendChild(inputEdit2);
        inputEdit2.setAttribute(`type`, `checkbox`);
        inputEdit2.checked = true;
        
    } else if (selectedText === `Java`) {
        document.querySelector(`.checkbox-edit`).style.display = `flex`;
        document.querySelector(`.checkbox-edit-1`).style.display = `flex`;
        document.querySelector(`.checkbox-edit-2`).style.display = `flex`;

        labelEdit.innerHTML = `Assignment  1`;
        labelEdit1.innerHTML = `Assignment  2`;
        labelEdit2.innerHTML = `Assignment  3`;

        labelEdit.style.fontSize = `20px`;
        labelEdit.style.fontWeight = `bold`;
        labelEdit.style.width = `30%`;

        labelEdit1.style.fontSize = `20px`;
        labelEdit1.style.fontWeight = `bold`;
        labelEdit1.style.width = `30%`;
        
        labelEdit2.style.fontSize = `20px`;
        labelEdit2.style.fontWeight = `bold`;
        labelEdit2.style.width = `30%`;

        document.querySelector(`.checkbox-edit`).appendChild(inputEdit);
        inputEdit.setAttribute(`type`, `checkbox`);
        inputEdit.checked = true;
        
        document.querySelector(`.checkbox-edit-1`).appendChild(inputEdit1);
        inputEdit1.setAttribute(`type`, `checkbox`);
        inputEdit1.checked = true;

        document.querySelector(`.checkbox-edit-2`).appendChild(inputEdit2);
        inputEdit2.setAttribute(`type`, `checkbox`);

    } else if (selectedText === `HTML & CSS`) {
        document.querySelector(`.checkbox-edit`).style.display = `flex`;
        document.querySelector(`.checkbox-edit-1`).style.display = `flex`;
        document.querySelector(`.checkbox-edit-2`).style.display = `flex`;

        labelEdit.innerHTML = `Assignment  4`;
        labelEdit1.innerHTML = `Assignment  5`;
        labelEdit2.innerHTML = `Assignment  6`;

        labelEdit.style.fontSize = `20px`;
        labelEdit.style.fontWeight = `bold`;
        labelEdit.style.width = `30%`;

        labelEdit1.style.fontSize = `20px`;
        labelEdit1.style.fontWeight = `bold`;
        labelEdit1.style.width = `30%`;
        
        labelEdit2.style.fontSize = `20px`;
        labelEdit2.style.fontWeight = `bold`;
        labelEdit2.style.width = `30%`;

        document.querySelector(`.checkbox-edit`).appendChild(inputEdit);
        inputEdit.setAttribute(`type`, `checkbox`);
        inputEdit.checked = true;
        
        document.querySelector(`.checkbox-edit-1`).appendChild(inputEdit1);
        inputEdit1.setAttribute(`type`, `checkbox`);
        inputEdit1.checked = true;

        document.querySelector(`.checkbox-edit-2`).appendChild(inputEdit2);
        inputEdit2.setAttribute(`type`, `checkbox`);
        inputEdit2.checked = true;

    } else {
        document.querySelector(`.checkbox-edit`).style.display = `none`;
        document.querySelector(`.checkbox-edit-1`).style.display = `none`;
        document.querySelector(`.checkbox-edit-2`).style.display = `none`;

    }
});

// End of container-2

document.querySelector(`.button`).addEventListener(`click`, function() {

    if (document.getElementById(`course-add`).value === `initial`) {

        alert(`You have not selected a value for the "Course:" attribute!`)
    }

    if (document.getElementById(`course-add`).value !== `initial` && input.checked === false && input1.checked === false && input2.checked === false) {
        alert(`You must check at least one box!`)
    }

})