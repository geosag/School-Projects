document.querySelector(`.checkbox-add`).style.display = `none`;
document.querySelector(`.checkbox-add-1`).style.display = `none`;
document.querySelector(`.checkbox-add-2`).style.display = `none`;

let select = document.querySelector("#course-add");

let label = document.createElement(`label`);
document.querySelector('.checkbox-add').appendChild(label);

let label1 = document.createElement(`label`);
document.querySelector('.checkbox-add-1').appendChild(label1);

let label2 = document.createElement(`label`);
document.querySelector('.checkbox-add-2').appendChild(label2);


let input = document.createElement(`input`);
let input1 = document.createElement(`input`);
let input2 = document.createElement(`input`);

let selectAddMenu = document.querySelector(`#select-add`);

let optionAdd1 = document.createElement(`option`);
document.querySelector('#select-add').appendChild(optionAdd1);
let optionAdd2 = document.createElement(`option`);
document.querySelector('#select-add').appendChild(optionAdd2);
let optionAdd3 = document.createElement(`option`);
document.querySelector('#select-add').appendChild(optionAdd3);
let optionAdd4 = document.createElement(`option`);
document.querySelector('#select-add').appendChild(optionAdd4);
    

select.addEventListener(`change`, function() {

    let selectedText = select.options[select.selectedIndex].text;

    if (selectedText === `Javascript`) {

        document.querySelector(`.checkbox-add`).style.display = `none`;
        document.querySelector(`.checkbox-add-1`).style.display = `none`;
        document.querySelector(`.checkbox-add-2`).style.display = `none`;

        document.querySelector(`.select-add`).style.display = `flex`;

        optionAdd1.innerHTML = `---&nbsp;&nbsp;---`;
        optionAdd1.setAttribute(`value`, `initial`);

        optionAdd2.innerHTML = `Student 7`;
        optionAdd2.setAttribute(`value`, `student-7`);

        optionAdd3.innerHTML = `Student 8`;
        optionAdd3.setAttribute(`value`, `student-8`);

        optionAdd4.innerHTML = `Student 9`;
        optionAdd4.setAttribute(`value`, `student-9`);

        document.getElementById(`select-add`).value = `initial`;
        
    } else if (selectedText === `Java`) {

        document.querySelector(`.checkbox-add`).style.display = `none`;
        document.querySelector(`.checkbox-add-1`).style.display = `none`;
        document.querySelector(`.checkbox-add-2`).style.display = `none`;

        document.querySelector(`.select-add`).style.display = `flex`;

        optionAdd1.innerHTML = `---&nbsp;&nbsp;---`;
        optionAdd1.setAttribute(`value`, `initial`);

        optionAdd2.innerHTML = `Student 1`;
        optionAdd2.setAttribute(`value`, `student-1`);

        optionAdd3.innerHTML = `Student 2`;
        optionAdd3.setAttribute(`value`, `student-2`);

        optionAdd4.innerHTML = `Student 3`;
        optionAdd4.setAttribute(`value`, `student-3`);
        
        document.getElementById(`select-add`).value = `initial`;

    } else if (selectedText === `HTML & CSS`) {
        
        document.querySelector(`.checkbox-add`).style.display = `none`;
        document.querySelector(`.checkbox-add-1`).style.display = `none`;
        document.querySelector(`.checkbox-add-2`).style.display = `none`;

        document.querySelector(`.select-add`).style.display = `flex`;

        optionAdd1.innerHTML = `---&nbsp;&nbsp;---`;
        optionAdd1.setAttribute(`value`, `initial`);

        optionAdd2.innerHTML = `Student 4`;
        optionAdd2.setAttribute(`value`, `student-4`);

        optionAdd3.innerHTML = `Student 5`;
        optionAdd3.setAttribute(`value`, `student-5`);

        optionAdd4.innerHTML = `Student 6`;
        optionAdd4.setAttribute(`value`, `student-6`);

        document.getElementById(`select-add`).value = `initial`;

    } else {
        document.querySelector(`.select-add`).style.display = `none`;
        
        document.querySelector(`.checkbox-add`).style.display = `none`;
        document.querySelector(`.checkbox-add-1`).style.display = `none`;
        document.querySelector(`.checkbox-add-2`).style.display = `none`;

    }
        
        });

    selectAddMenu.addEventListener(`change`, function() {

        let selectedTextAdd = selectAddMenu.options[selectAddMenu.selectedIndex].text;

        if (selectedTextAdd === `Student 7`) {

        document.querySelector(`.checkbox-add`).style.display = `flex`;
        document.querySelector(`.checkbox-add-1`).style.display = `flex`;
        document.querySelector(`.checkbox-add-2`).style.display = `flex`;
            
        label.innerHTML = `Assignment 1`;
        label1.innerHTML = `Assignment 2`;
        label2.innerHTML = `Assignment 3`;

        label.style.fontSize = `20px`;
        label.style.fontWeight = `bold`;
        label.style.width = `30%`;

        label1.style.fontSize = `20px`;
        label1.style.fontWeight = `bold`;
        label1.style.width = `30%`;
        
        label2.style.fontSize = `20px`;
        label2.style.fontWeight = `bold`;
        label2.style.width = `30%`;

        document.querySelector(`.checkbox-add`).appendChild(input);
        input.setAttribute(`type`, `checkbox`);
        
        document.querySelector(`.checkbox-add-1`).appendChild(input1);
        input1.setAttribute(`type`, `checkbox`);

        document.querySelector(`.checkbox-add-2`).appendChild(input2);
        input2.setAttribute(`type`, `checkbox`);

        } else if (selectedTextAdd === `Student 8`) {

        document.querySelector(`.checkbox-add`).style.display = `flex`;
        document.querySelector(`.checkbox-add-1`).style.display = `flex`;
        document.querySelector(`.checkbox-add-2`).style.display = `flex`;
            
        label.innerHTML = `Assignment 4`;
        label1.innerHTML = `Assignment 5`;
        label2.innerHTML = `Assignment 6`;

        label.style.fontSize = `20px`;
        label.style.fontWeight = `bold`;
        label.style.width = `30%`;

        label1.style.fontSize = `20px`;
        label1.style.fontWeight = `bold`;
        label1.style.width = `30%`;
        
        label2.style.fontSize = `20px`;
        label2.style.fontWeight = `bold`;
        label2.style.width = `30%`;

        document.querySelector(`.checkbox-add`).appendChild(input);
        input.setAttribute(`type`, `checkbox`);
        
        document.querySelector(`.checkbox-add-1`).appendChild(input1);
        input1.setAttribute(`type`, `checkbox`);

        document.querySelector(`.checkbox-add-2`).appendChild(input2);
        input2.setAttribute(`type`, `checkbox`);

        } else if (selectedTextAdd === `Student 9`) {
        document.querySelector(`.checkbox-add`).style.display = `flex`;
        document.querySelector(`.checkbox-add-1`).style.display = `flex`;
        document.querySelector(`.checkbox-add-2`).style.display = `flex`;
            
        label.innerHTML = `Assignment 7`;
        label1.innerHTML = `Assignment 8`;
        label2.innerHTML = `Assignment 9`;

        label.style.fontSize = `20px`;
        label.style.fontWeight = `bold`;
        label.style.width = `30%`;

        label1.style.fontSize = `20px`;
        label1.style.fontWeight = `bold`;
        label1.style.width = `30%`;
        
        label2.style.fontSize = `20px`;
        label2.style.fontWeight = `bold`;
        label2.style.width = `30%`;

        document.querySelector(`.checkbox-add`).appendChild(input);
        input.setAttribute(`type`, `checkbox`);
        
        document.querySelector(`.checkbox-add-1`).appendChild(input1);
        input1.setAttribute(`type`, `checkbox`);

        document.querySelector(`.checkbox-add-2`).appendChild(input2);
        input2.setAttribute(`type`, `checkbox`);
        } else if (selectedTextAdd === `Student 1`) {

        document.querySelector(`.checkbox-add`).style.display = `flex`;
        document.querySelector(`.checkbox-add-1`).style.display = `flex`;
        document.querySelector(`.checkbox-add-2`).style.display = `flex`;
            
        label.innerHTML = `Assignment 1`;
        label1.innerHTML = `Assignment 2`;
        label2.innerHTML = `Assignment 3`;

        label.style.fontSize = `20px`;
        label.style.fontWeight = `bold`;
        label.style.width = `30%`;

        label1.style.fontSize = `20px`;
        label1.style.fontWeight = `bold`;
        label1.style.width = `30%`;
        
        label2.style.fontSize = `20px`;
        label2.style.fontWeight = `bold`;
        label2.style.width = `30%`;

        document.querySelector(`.checkbox-add`).appendChild(input);
        input.setAttribute(`type`, `checkbox`);
        
        document.querySelector(`.checkbox-add-1`).appendChild(input1);
        input1.setAttribute(`type`, `checkbox`);

        document.querySelector(`.checkbox-add-2`).appendChild(input2);
        input2.setAttribute(`type`, `checkbox`);

        } else if (selectedTextAdd === `Student 2`) {
        document.querySelector(`.checkbox-add`).style.display = `flex`;
        document.querySelector(`.checkbox-add-1`).style.display = `flex`;
        document.querySelector(`.checkbox-add-2`).style.display = `flex`;
            
        label.innerHTML = ` Assignment 4`;
        label1.innerHTML = `Assignment 5`;
        label2.innerHTML = `Assignment 6`;

        label.style.fontSize = `20px`;
        label.style.fontWeight = `bold`;
        label.style.width = `30%`;

        label1.style.fontSize = `20px`;
        label1.style.fontWeight = `bold`;
        label1.style.width = `30%`;
        
        label2.style.fontSize = `20px`;
        label2.style.fontWeight = `bold`;
        label2.style.width = `30%`;

        document.querySelector(`.checkbox-add`).appendChild(input);
        input.setAttribute(`type`, `checkbox`);
        
        document.querySelector(`.checkbox-add-1`).appendChild(input1);
        input1.setAttribute(`type`, `checkbox`);

        document.querySelector(`.checkbox-add-2`).appendChild(input2);
        input2.setAttribute(`type`, `checkbox`);

        } else if (selectedTextAdd === `Student 3`) {

            document.querySelector(`.checkbox-add`).style.display = `flex`;
            document.querySelector(`.checkbox-add-1`).style.display = `flex`;
            document.querySelector(`.checkbox-add-2`).style.display = `flex`;
                
            label.innerHTML = ` Assignment 7`;
            label1.innerHTML = `Assignment 8`;
            label2.innerHTML = `Assignment 9`;
    
            label.style.fontSize = `20px`;
            label.style.fontWeight = `bold`;
            label.style.width = `30%`;
    
            label1.style.fontSize = `20px`;
            label1.style.fontWeight = `bold`;
            label1.style.width = `30%`;
            
            label2.style.fontSize = `20px`;
            label2.style.fontWeight = `bold`;
            label2.style.width = `30%`;
    
            document.querySelector(`.checkbox-add`).appendChild(input);
            input.setAttribute(`type`, `checkbox`);
            
            document.querySelector(`.checkbox-add-1`).appendChild(input1);
            input1.setAttribute(`type`, `checkbox`);
    
            document.querySelector(`.checkbox-add-2`).appendChild(input2);
            input2.setAttribute(`type`, `checkbox`);
        } else if (selectedTextAdd === `Student 4`) {

            document.querySelector(`.checkbox-add`).style.display = `flex`;
            document.querySelector(`.checkbox-add-1`).style.display = `flex`;
            document.querySelector(`.checkbox-add-2`).style.display = `flex`;
                
            label.innerHTML = ` Assignment 1`;
            label1.innerHTML = `Assignment 2`;
            label2.innerHTML = `Assignment 3`;
    
            label.style.fontSize = `20px`;
            label.style.fontWeight = `bold`;
            label.style.width = `30%`;
    
            label1.style.fontSize = `20px`;
            label1.style.fontWeight = `bold`;
            label1.style.width = `30%`;
            
            label2.style.fontSize = `20px`;
            label2.style.fontWeight = `bold`;
            label2.style.width = `30%`;
    
            document.querySelector(`.checkbox-add`).appendChild(input);
            input.setAttribute(`type`, `checkbox`);
            
            document.querySelector(`.checkbox-add-1`).appendChild(input1);
            input1.setAttribute(`type`, `checkbox`);
    
            document.querySelector(`.checkbox-add-2`).appendChild(input2);
            input2.setAttribute(`type`, `checkbox`);
        } else if (selectedTextAdd === `Student 5`) {
            document.querySelector(`.checkbox-add`).style.display = `flex`;
            document.querySelector(`.checkbox-add-1`).style.display = `flex`;
            document.querySelector(`.checkbox-add-2`).style.display = `flex`;
                
            label.innerHTML = ` Assignment 4`;
            label1.innerHTML = `Assignment 5`;
            label2.innerHTML = `Assignment 6`;
    
            label.style.fontSize = `20px`;
            label.style.fontWeight = `bold`;
            label.style.width = `30%`;
    
            label1.style.fontSize = `20px`;
            label1.style.fontWeight = `bold`;
            label1.style.width = `30%`;
            
            label2.style.fontSize = `20px`;
            label2.style.fontWeight = `bold`;
            label2.style.width = `30%`;
    
            document.querySelector(`.checkbox-add`).appendChild(input);
            input.setAttribute(`type`, `checkbox`);
            
            document.querySelector(`.checkbox-add-1`).appendChild(input1);
            input1.setAttribute(`type`, `checkbox`);
    
            document.querySelector(`.checkbox-add-2`).appendChild(input2);
            input2.setAttribute(`type`, `checkbox`);
        } else if (selectedTextAdd === `Student 6`) {
            document.querySelector(`.checkbox-add`).style.display = `flex`;
            document.querySelector(`.checkbox-add-1`).style.display = `flex`;
            document.querySelector(`.checkbox-add-2`).style.display = `flex`;
                
            label.innerHTML = ` Assignment 7`;
            label1.innerHTML = `Assignment 8`;
            label2.innerHTML = `Assignment 9`;
    
            label.style.fontSize = `20px`;
            label.style.fontWeight = `bold`;
            label.style.width = `30%`;
    
            label1.style.fontSize = `20px`;
            label1.style.fontWeight = `bold`;
            label1.style.width = `30%`;
            
            label2.style.fontSize = `20px`;
            label2.style.fontWeight = `bold`;
            label2.style.width = `30%`;
    
            document.querySelector(`.checkbox-add`).appendChild(input);
            input.setAttribute(`type`, `checkbox`);
            
            document.querySelector(`.checkbox-add-1`).appendChild(input1);
            input1.setAttribute(`type`, `checkbox`);
    
            document.querySelector(`.checkbox-add-2`).appendChild(input2);
            input2.setAttribute(`type`, `checkbox`);
        } else {
            document.querySelector(`.checkbox-add`).style.display = `none`;
            document.querySelector(`.checkbox-add-1`).style.display = `none`;
            document.querySelector(`.checkbox-add-2`).style.display = `none`;
        }

    });


// End of container-1

let select1 = document.querySelector("#course-edit");

let labelEdit = document.createElement(`label`);
document.querySelector('.checkbox-edit').appendChild(labelEdit);

let labelEdit1 = document.createElement(`label`);
document.querySelector('.checkbox-edit-1').appendChild(labelEdit1);

let labelEdit2 = document.createElement(`label`);
document.querySelector('.checkbox-edit-2').appendChild(labelEdit2);

labelEdit.innerHTML = `Assignment 7`;
labelEdit1.innerHTML = `Assignment 8`;
labelEdit2.innerHTML = `Assignment 9`;

let inputEdit = document.createElement(`input`);
let inputEdit1 = document.createElement(`input`);
let inputEdit2 = document.createElement(`input`);

labelEdit.style.fontSize = `20px`;
labelEdit.style.fontWeight = `bold`;
labelEdit.style.width = `30%`;

labelEdit1.style.fontSize = `20px`;
labelEdit1.style.fontWeight = `bold`;
labelEdit1.style.width = `30%`;
        
labelEdit2.style.fontSize = `20px`;
labelEdit2.style.fontWeight = `bold`;
labelEdit2.style.width = `30%`;

document.querySelector(`.checkbox-edit`).appendChild(inputEdit);
inputEdit.setAttribute(`type`, `checkbox`);
inputEdit.checked = true;

document.querySelector(`.checkbox-edit-1`).appendChild(inputEdit1);
inputEdit1.setAttribute(`type`, `checkbox`);

document.querySelector(`.checkbox-edit-2`).appendChild(inputEdit2);
inputEdit2.setAttribute(`type`, `checkbox`);
inputEdit2.checked = true;

let selectEditMenu = document.querySelector(`#select-edit`);

let optionEdit1 = document.createElement(`option`);
document.querySelector('#select-edit').appendChild(optionEdit1);
let optionEdit2 = document.createElement(`option`);
document.querySelector('#select-edit').appendChild(optionEdit2);
let optionEdit3 = document.createElement(`option`);
document.querySelector('#select-edit').appendChild(optionEdit3);
let optionEdit4 = document.createElement(`option`);
document.querySelector('#select-edit').appendChild(optionEdit4);

optionEdit1.innerHTML = `---&nbsp;&nbsp;---`;
optionEdit1.setAttribute(`value`, `initial`);

optionEdit2.innerHTML = `Student 1`;
optionEdit2.setAttribute(`value`, `student-1`);

optionEdit3.innerHTML = `Student 2`;
optionEdit3.setAttribute(`value`, `student-2`);

optionEdit4.innerHTML = `Student 3`;
optionEdit4.setAttribute(`value`, `student-3`);

document.getElementById(`select-edit`).value = `student-3`;

select1.addEventListener(`change`, function() {

    inputEdit.checked = false;
    inputEdit1.checked = false;
    inputEdit2.checked = false;

    let selectedText = select1.options[select1.selectedIndex].text;

    if (selectedText === `Javascript`) {

        document.querySelector(`.checkbox-edit`).style.display = `none`;
        document.querySelector(`.checkbox-edit-1`).style.display = `none`;
        document.querySelector(`.checkbox-edit-2`).style.display = `none`;

        document.querySelector(`.select-edit`).style.display = `flex`;

        optionEdit1.innerHTML = `---&nbsp;&nbsp;---`;
        optionEdit1.setAttribute(`value`, `initial`);

        optionEdit2.innerHTML = `Student 7`;
        optionEdit2.setAttribute(`value`, `student-7`);

        optionEdit3.innerHTML = `Student 8`;
        optionEdit3.setAttribute(`value`, `student-8`);

        optionEdit4.innerHTML = `Student 9`;
        optionEdit4.setAttribute(`value`, `student-9`);

        document.getElementById(`select-edit`).value = `initial`;
        
    } else if (selectedText === `Java`) {
        document.querySelector(`.checkbox-edit`).style.display = `none`;
        document.querySelector(`.checkbox-edit-1`).style.display = `none`;
        document.querySelector(`.checkbox-edit-2`).style.display = `none`;

        document.querySelector(`.select-edit`).style.display = `flex`;

        optionEdit1.innerHTML = `---&nbsp;&nbsp;---`;
        optionEdit1.setAttribute(`value`, `initial`);

        optionEdit2.innerHTML = `Student 1`;
        optionEdit2.setAttribute(`value`, `student-1`);

        optionEdit3.innerHTML = `Student 2`;
        optionEdit3.setAttribute(`value`, `student-2`);

        optionEdit4.innerHTML = `Student 3`;
        optionEdit4.setAttribute(`value`, `student-3`);

        document.getElementById(`select-edit`).value = `initial`;

    } else if (selectedText === `HTML & CSS`) {
        document.querySelector(`.checkbox-edit`).style.display = `none`;
        document.querySelector(`.checkbox-edit-1`).style.display = `none`;
        document.querySelector(`.checkbox-edit-2`).style.display = `none`;

        document.querySelector(`.select-edit`).style.display = `flex`;

        optionEdit1.innerHTML = `---&nbsp;&nbsp;---`;
        optionEdit1.setAttribute(`value`, `initial`);

        optionEdit2.innerHTML = `Student 4`;
        optionEdit2.setAttribute(`value`, `student-4`);

        optionEdit3.innerHTML = `Student 5`;
        optionEdit3.setAttribute(`value`, `student-5`);

        optionEdit4.innerHTML = `Student 6`;
        optionEdit4.setAttribute(`value`, `student-6`);

        document.getElementById(`select-edit`).value = `initial`;

    } else {
        document.querySelector(`.select-edit`).style.display = `none`;

        document.querySelector(`.checkbox-edit`).style.display = `none`;
        document.querySelector(`.checkbox-edit-1`).style.display = `none`;
        document.querySelector(`.checkbox-edit-2`).style.display = `none`;

    }
});

selectEditMenu.addEventListener(`change`, function() {

    let selectedTextEdit = selectEditMenu.options[selectEditMenu.selectedIndex].text;

    if (selectedTextEdit === `Student 7`) {

    document.querySelector(`.checkbox-edit`).style.display = `flex`;
    document.querySelector(`.checkbox-edit-1`).style.display = `flex`;
    document.querySelector(`.checkbox-edit-2`).style.display = `flex`;
        
        labelEdit.innerHTML = `Assignment 1`;
        labelEdit1.innerHTML = `Assignment 2`;
        labelEdit2.innerHTML = `Assignment 3`;

        labelEdit.style.fontSize = `20px`;
        labelEdit.style.fontWeight = `bold`;
        labelEdit.style.width = `30%`;

        labelEdit1.style.fontSize = `20px`;
        labelEdit1.style.fontWeight = `bold`;
        labelEdit1.style.width = `30%`;
        
        labelEdit2.style.fontSize = `20px`;
        labelEdit2.style.fontWeight = `bold`;
        labelEdit2.style.width = `30%`;

        document.querySelector(`.checkbox-edit`).appendChild(inputEdit);
        inputEdit.setAttribute(`type`, `checkbox`);
        inputEdit.checked = true;
        
        
        document.querySelector(`.checkbox-edit-1`).appendChild(inputEdit1);
        inputEdit1.setAttribute(`type`, `checkbox`);
        inputEdit1.checked = false;

        document.querySelector(`.checkbox-edit-2`).appendChild(inputEdit2);
        inputEdit2.setAttribute(`type`, `checkbox`);
        inputEdit2.checked = true;

    } else if (selectedTextEdit === `Student 8`) {

    document.querySelector(`.checkbox-edit`).style.display = `flex`;
    document.querySelector(`.checkbox-edit-1`).style.display = `flex`;
    document.querySelector(`.checkbox-edit-2`).style.display = `flex`;
        
    labelEdit.innerHTML = `Assignment 4`;
        labelEdit1.innerHTML = `Assignment 5`;
        labelEdit2.innerHTML = `Assignment 6`;

        labelEdit.style.fontSize = `20px`;
        labelEdit.style.fontWeight = `bold`;
        labelEdit.style.width = `30%`;

        labelEdit1.style.fontSize = `20px`;
        labelEdit1.style.fontWeight = `bold`;
        labelEdit1.style.width = `30%`;
        
        labelEdit2.style.fontSize = `20px`;
        labelEdit2.style.fontWeight = `bold`;
        labelEdit2.style.width = `30%`;

        document.querySelector(`.checkbox-edit`).appendChild(inputEdit);
        inputEdit.setAttribute(`type`, `checkbox`);
        inputEdit.checked = true;
        
        document.querySelector(`.checkbox-edit-1`).appendChild(inputEdit1);
        inputEdit1.setAttribute(`type`, `checkbox`);
        inputEdit1.checked = true;

        document.querySelector(`.checkbox-edit-2`).appendChild(inputEdit2);
        inputEdit2.setAttribute(`type`, `checkbox`);
        inputEdit2.checked = true;

    } else if (selectedTextEdit === `Student 9`) {
        document.querySelector(`.checkbox-edit`).style.display = `flex`;
        document.querySelector(`.checkbox-edit-1`).style.display = `flex`;
        document.querySelector(`.checkbox-edit-2`).style.display = `flex`;
            
            labelEdit.innerHTML = `Assignment 7`;
            labelEdit1.innerHTML = `Assignment 8`;
            labelEdit2.innerHTML = `Assignment 9`;
    
            labelEdit.style.fontSize = `20px`;
            labelEdit.style.fontWeight = `bold`;
            labelEdit.style.width = `30%`;
    
            labelEdit1.style.fontSize = `20px`;
            labelEdit1.style.fontWeight = `bold`;
            labelEdit1.style.width = `30%`;
            
            labelEdit2.style.fontSize = `20px`;
            labelEdit2.style.fontWeight = `bold`;
            labelEdit2.style.width = `30%`;
    
            document.querySelector(`.checkbox-edit`).appendChild(inputEdit);
            inputEdit.setAttribute(`type`, `checkbox`);
            inputEdit.checked = false;
            
            document.querySelector(`.checkbox-edit-1`).appendChild(inputEdit1);
            inputEdit1.setAttribute(`type`, `checkbox`);
            inputEdit1.checked = true;
    
            document.querySelector(`.checkbox-edit-2`).appendChild(inputEdit2);
            inputEdit2.setAttribute(`type`, `checkbox`);
            inputEdit2.checked = true;
    } else if (selectedTextEdit === `Student 1`) {

        document.querySelector(`.checkbox-edit`).style.display = `flex`;
        document.querySelector(`.checkbox-edit-1`).style.display = `flex`;
        document.querySelector(`.checkbox-edit-2`).style.display = `flex`;
            
            labelEdit.innerHTML = `Assignment 1`;
            labelEdit1.innerHTML = `Assignment 2`;
            labelEdit2.innerHTML = `Assignment 3`;
    
            labelEdit.style.fontSize = `20px`;
            labelEdit.style.fontWeight = `bold`;
            labelEdit.style.width = `30%`;
    
            labelEdit1.style.fontSize = `20px`;
            labelEdit1.style.fontWeight = `bold`;
            labelEdit1.style.width = `30%`;
            
            labelEdit2.style.fontSize = `20px`;
            labelEdit2.style.fontWeight = `bold`;
            labelEdit2.style.width = `30%`;
    
            document.querySelector(`.checkbox-edit`).appendChild(inputEdit);
            inputEdit.setAttribute(`type`, `checkbox`);
            inputEdit.checked = true;
            
            document.querySelector(`.checkbox-edit-1`).appendChild(inputEdit1);
            inputEdit1.setAttribute(`type`, `checkbox`);
            inputEdit1.checked = true;
    
            document.querySelector(`.checkbox-edit-2`).appendChild(inputEdit2);
            inputEdit2.setAttribute(`type`, `checkbox`);
            inputEdit2.checked = false;

    } else if (selectedTextEdit === `Student 2`) {
        document.querySelector(`.checkbox-edit`).style.display = `flex`;
        document.querySelector(`.checkbox-edit-1`).style.display = `flex`;
        document.querySelector(`.checkbox-edit-2`).style.display = `flex`;
            
            labelEdit.innerHTML = `Assignment 4`;
            labelEdit1.innerHTML = `Assignment 5`;
            labelEdit2.innerHTML = `Assignment 6`;
    
            labelEdit.style.fontSize = `20px`;
            labelEdit.style.fontWeight = `bold`;
            labelEdit.style.width = `30%`;
    
            labelEdit1.style.fontSize = `20px`;
            labelEdit1.style.fontWeight = `bold`;
            labelEdit1.style.width = `30%`;
            
            labelEdit2.style.fontSize = `20px`;
            labelEdit2.style.fontWeight = `bold`;
            labelEdit2.style.width = `30%`;
    
            document.querySelector(`.checkbox-edit`).appendChild(inputEdit);
            inputEdit.setAttribute(`type`, `checkbox`);
            inputEdit.checked = false;
            
            
            document.querySelector(`.checkbox-edit-1`).appendChild(inputEdit1);
            inputEdit1.setAttribute(`type`, `checkbox`);
            inputEdit1.checked = true;
            
    
            document.querySelector(`.checkbox-edit-2`).appendChild(inputEdit2);
            inputEdit2.setAttribute(`type`, `checkbox`);
            inputEdit2.checked = false;

    } else if (selectedTextEdit === `Student 3`) {

        document.querySelector(`.checkbox-edit`).style.display = `flex`;
        document.querySelector(`.checkbox-edit-1`).style.display = `flex`;
        document.querySelector(`.checkbox-edit-2`).style.display = `flex`;
            
            labelEdit.innerHTML = `Assignment 7`;
            labelEdit1.innerHTML = `Assignment 8`;
            labelEdit2.innerHTML = `Assignment 9`;
    
            labelEdit.style.fontSize = `20px`;
            labelEdit.style.fontWeight = `bold`;
            labelEdit.style.width = `30%`;
    
            labelEdit1.style.fontSize = `20px`;
            labelEdit1.style.fontWeight = `bold`;
            labelEdit1.style.width = `30%`;
            
            labelEdit2.style.fontSize = `20px`;
            labelEdit2.style.fontWeight = `bold`;
            labelEdit2.style.width = `30%`;
    
            document.querySelector(`.checkbox-edit`).appendChild(inputEdit);
            inputEdit.setAttribute(`type`, `checkbox`);
            inputEdit.checked = true;
            
            document.querySelector(`.checkbox-edit-1`).appendChild(inputEdit1);
            inputEdit1.setAttribute(`type`, `checkbox`);
            inputEdit1.checked = false;
    
            document.querySelector(`.checkbox-edit-2`).appendChild(inputEdit2);
            inputEdit2.setAttribute(`type`, `checkbox`);
            inputEdit2.checked = true;

    } else if (selectedTextEdit === `Student 4`) {

        document.querySelector(`.checkbox-edit`).style.display = `flex`;
        document.querySelector(`.checkbox-edit-1`).style.display = `flex`;
        document.querySelector(`.checkbox-edit-2`).style.display = `flex`;
            
            labelEdit.innerHTML = `Assignment 1`;
            labelEdit1.innerHTML = `Assignment 2`;
            labelEdit2.innerHTML = `Assignment 3`;
    
            labelEdit.style.fontSize = `20px`;
            labelEdit.style.fontWeight = `bold`;
            labelEdit.style.width = `30%`;
    
            labelEdit1.style.fontSize = `20px`;
            labelEdit1.style.fontWeight = `bold`;
            labelEdit1.style.width = `30%`;
            
            labelEdit2.style.fontSize = `20px`;
            labelEdit2.style.fontWeight = `bold`;
            labelEdit2.style.width = `30%`;
    
            document.querySelector(`.checkbox-edit`).appendChild(inputEdit);
            inputEdit.setAttribute(`type`, `checkbox`);
            inputEdit.checked = true;
            
            document.querySelector(`.checkbox-edit-1`).appendChild(inputEdit1);
            inputEdit1.setAttribute(`type`, `checkbox`);
            inputEdit1.checked = false;
    
            document.querySelector(`.checkbox-edit-2`).appendChild(inputEdit2);
            inputEdit2.setAttribute(`type`, `checkbox`);
            inputEdit2.checked = false;

    } else if (selectedTextEdit === `Student 5`) {
        document.querySelector(`.checkbox-edit`).style.display = `flex`;
        document.querySelector(`.checkbox-edit-1`).style.display = `flex`;
        document.querySelector(`.checkbox-edit-2`).style.display = `flex`;
            
            labelEdit.innerHTML = `Assignment 4`;
            labelEdit1.innerHTML = `Assignment 5`;
            labelEdit2.innerHTML = `Assignment 6`;
    
            labelEdit.style.fontSize = `20px`;
            labelEdit.style.fontWeight = `bold`;
            labelEdit.style.width = `30%`;
    
            labelEdit1.style.fontSize = `20px`;
            labelEdit1.style.fontWeight = `bold`;
            labelEdit1.style.width = `30%`;
            
            labelEdit2.style.fontSize = `20px`;
            labelEdit2.style.fontWeight = `bold`;
            labelEdit2.style.width = `30%`;
    
            document.querySelector(`.checkbox-edit`).appendChild(inputEdit);
            inputEdit.setAttribute(`type`, `checkbox`);
            inputEdit.checked = false;
            
            document.querySelector(`.checkbox-edit-1`).appendChild(inputEdit1);
            inputEdit1.setAttribute(`type`, `checkbox`);
            inputEdit1.checked = false;
    
            document.querySelector(`.checkbox-edit-2`).appendChild(inputEdit2);
            inputEdit2.setAttribute(`type`, `checkbox`);
            inputEdit2.checked = true;

    } else if (selectedTextEdit === `Student 6`) {
        document.querySelector(`.checkbox-edit`).style.display = `flex`;
        document.querySelector(`.checkbox-edit-1`).style.display = `flex`;
        document.querySelector(`.checkbox-edit-2`).style.display = `flex`;
            
            labelEdit.innerHTML = `Assignment 7`;
            labelEdit1.innerHTML = `Assignment 8`;
            labelEdit2.innerHTML = `Assignment 9`;
    
            labelEdit.style.fontSize = `20px`;
            labelEdit.style.fontWeight = `bold`;
            labelEdit.style.width = `30%`;
    
            labelEdit1.style.fontSize = `20px`;
            labelEdit1.style.fontWeight = `bold`;
            labelEdit1.style.width = `30%`;
            
            labelEdit2.style.fontSize = `20px`;
            labelEdit2.style.fontWeight = `bold`;
            labelEdit2.style.width = `30%`;
    
            document.querySelector(`.checkbox-edit`).appendChild(inputEdit);
            inputEdit.setAttribute(`type`, `checkbox`);
            inputEdit.checked = true;
            
            document.querySelector(`.checkbox-edit-1`).appendChild(inputEdit1);
            inputEdit1.setAttribute(`type`, `checkbox`);
            inputEdit1.checked = true;
    
            document.querySelector(`.checkbox-edit-2`).appendChild(inputEdit2);
            inputEdit2.setAttribute(`type`, `checkbox`);
            inputEdit2.checked = false;
    } else {
        document.querySelector(`.checkbox-edit`).style.display = `none`;
        document.querySelector(`.checkbox-edit-1`).style.display = `none`;
        document.querySelector(`.checkbox-edit-2`).style.display = `none`;
    }

});

// End of container-2

document.querySelector(`.button`).addEventListener(`click`, function() {

    if (document.getElementById(`course-add`).value === `initial`) {

        alert(`You have not selected a value for the "Course:" attribute!`)
    }

    if (document.getElementById(`select-add`).value === `initial`) {
        alert(`You have not selected a value for the "Student:" attribute!`)
    }

    if (document.getElementById(`course-add`).value !== `initial` && 
    document.getElementById(`select-add`).value !== `initial` && 
    input.checked === false && input1.checked === false && input2.checked === false) {
        alert(`You must check at least one box!`)
    }

})