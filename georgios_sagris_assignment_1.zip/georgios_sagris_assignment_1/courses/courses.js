document.querySelector(`.button`).addEventListener(`click`, function(){

    if (document.getElementById(`type-add`).value === `initial`) {
        alert(`You have not selected a value for the "Type:" attribute!`)
    }

    function compareDateAdd() {
        var str = document.getElementById("start-date-add").value;
        var end = document.getElementById("end-date-add").value;
        var year = str.substring(0,4);
        var month = str.substring(5,7);
        var date = str.substring(8,10);
        var endYear = end.substring(0,4);
        var endMonth = end.substring(5,7);
        var endDate = end.substring(8,10);
        var startDate = new Date(year, month-1, date);
        var endDate = new Date(endYear, endMonth-1, endDate);
    
        if (startDate > endDate) {
          alert('Start Date should be less than End Date!');
           return false;
        } 
        else { return true; }
    }

    compareDateAdd();

});